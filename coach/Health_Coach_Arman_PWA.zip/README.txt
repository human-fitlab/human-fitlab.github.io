# Health Coach Arman - Installable PWA

## Files
- `index.html` - app
- `manifest.webmanifest` - install metadata
- `sw.js` - offline app shell caching
- `icon.svg` - app icon

## Publish with GitHub Pages
1. Open the GitHub repository that hosts your website.
2. Upload these four files to the folder you want to publish as the app.
   - If you want the app at the root of the site, upload them to the repository root.
   - If you want it under a path such as `/coach/`, upload all four into a `coach` folder.
3. Commit the changes.
4. In GitHub, open **Settings → Pages** and make sure GitHub Pages is enabled for the correct branch/folder.
5. Wait for the HTTPS website URL to become available.
6. Open the published app URL in Chrome on Android.
7. Tap Chrome's three-dot menu. Choose **Install app** or **Add to Home screen**, then confirm.

## Important
- PWA installation requires a secure HTTPS website (GitHub Pages provides HTTPS).
- Do not open `index.html` from Downloads. The app must be opened from its published `https://` address.
- Client records currently use this browser's local storage. They do not sync between devices or users.
- Export a backup regularly from the app. Clearing browser data can remove local records.
- This first PWA package caches the app shell for repeat/offline opening. Features that require internet may not work offline.
